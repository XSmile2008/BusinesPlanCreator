﻿using System;
using System.Text;
using System.Windows.Forms;

using xNet;
namespace WebParser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string ConvertSource(String sourceWebPage)
        {
            Encoding utf8 = Encoding.GetEncoding("UTF-8");
            Encoding win1251 = Encoding.GetEncoding("Windows-1251");

            byte[] utf8Bytes = win1251.GetBytes(sourceWebPage);
            byte[] win1251Bytes = Encoding.Convert(utf8, win1251, utf8Bytes);
            sourceWebPage = win1251.GetString(win1251Bytes);
            return sourceWebPage;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var request = new HttpRequest())
            {
                String sourceWebPage = request.Get(textBox1.Text).ToString();
               
                textBox2.Text = sourceWebPage;
            }
           
        }
    }
}
